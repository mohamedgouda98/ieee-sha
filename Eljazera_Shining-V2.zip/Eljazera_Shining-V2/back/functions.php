<?php

include 'dbcont.php';

// function slider(){
//     global $cont;
//     $arr=array();
// $sql="SELECT * FROM slider";
// $stmt=$con->prepare($sql);

// $stmt->execute();

// while($row = $stmt->fetch()){

//     $arr[] = $row;


// }

// }





