

<div class="row">
    <div class="col-md-12 footer">
        Powerd By <b>The Factory</b>
    </div>
</div>

<script src="js/new.js"></script>
    </body>

</html>