
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
     <link rel="stylesheet" href="css/bootstrap.min.css"> 
        <link rel="stylesheet" href="css/all.min.css">
        <link rel="stylesheet" href="css/index_style.css">
        
        
        
        <script src="js/jquery-3.4.1.min.js"></script>    
        <script src="js/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <title>form</title>
      
        
    </head>
    <body>

          <!-- Start Header -->

          <div class="header">  
        <div class="row">
            <div class="col-md-4 logo">
                <img src="images/logo1.png">
            </div>

            <div class="col-md-4">
                name
            </div>

            <div class="col-md-4 logo">
                logo2
            </div>
        </div>
    </div>

        <!-- End Header -->