function myFunction() {
  window.print();
}