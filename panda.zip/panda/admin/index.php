<?php
    session_start();
    ob_start();

    if(isset($_SESSION['email'])){
        

    include '../back/functions.php';

    $action = isset($_GET['action']) ? $_GET['action']:'slider';
    $lang   = isset($_GET['lang']) ? $_GET['lang']:'1';

    $Img_Link = '../upload';

?>
<!DOCTYPE html>
<html lang="en" dir="rtl">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Responsive Admin Dashboard Template">
        <meta name="keywords" content="admin,dashboard">
        <meta name="author" content="skcats">
        <!-- The above 6 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        
        <!-- Title -->
        <title>Panda Nursery | Admin</title>

        <!-- Styles -->
        <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/css/font-awesome.min.css" rel="stylesheet">
        <!-- Theme Styles -->
        <link href="assets/css/ecaps.min.css" rel="stylesheet">
        <link href="assets/css/custom.css" rel="stylesheet">

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        
        <!-- Page Container -->
        <div class="page-container">
            <!-- Page Sidebar -->
            <div class="page-sidebar">
                <a class="logo-box" href="index.html">
                    <span>Panda Nursery</span>
                    <i class="icon-radio_button_unchecked" id="fixed-sidebar-toggle-button"></i>
                    <i class="icon-close" id="sidebar-toggle-button-close"></i>
                </a>
                <div class="page-sidebar-inner">
                    <div class="page-sidebar-menu">
                        <ul class="accordion-menu">
                            <li class="active-page">
                                <a href="index.php?lang=<?php echo $lang ?>">
                                    <i class="menu-icon icon-home4"></i><span>Dashboard</span>
                                </a>
                            </li>
                            <li>
                                <a href="index.php?action=slider&lang=<?php echo $lang ?>">
                                    <i class="menu-icon icon-inbox"></i><span>Edit Slider</span>
                                </a>
                            </li>
                            <li >
                                 <a href="index.php?action=about&lang=<?php echo $lang ?>">
                                    <i class="menu-icon icon-inbox"></i><span>Edit About</span>
                                </a>
                            </li>
                            <li>
                                <a href="index.php?action=services&lang=<?php echo $lang ?>">
                                    <i class="menu-icon icon-inbox"></i><span>Edit Services</span>
                                </a>
                            </li>
                            
                            <li>
                                <a href="index.php?action=gallery&lang=<?php echo $lang ?>">
                                    <i class="menu-icon icon-inbox"></i><span>Edit Gallery</span>
                                </a>
                            </li>
                                
                            <li>
                                <a href="index.php?action=contact&lang=<?php echo $lang ?>">
                                    <i class="menu-icon icon-inbox"></i><span>Edit Contact</span>
                                </a>
                            </li>
                            <li >
                                <a href="profile.php">
                                    <i class="menu-icon icon-inbox"></i><span>Profile</span>
                                </a>
                            </li>
                            <li>
                                <a href="logout.php">
                                    <i class="menu-icon icon-inbox"></i><span>Log Out</span>
                                </a>
                            </li>

                        </ul>
                    </div>
                </div>
            </div><!-- /Page Sidebar -->
            
            <!-- Page Content -->
            <div class="page-content">
                <!-- Page Header -->
                <div class="page-header">
                    <div class="search-form">
                        <form action="#" method="GET">
                            <div class="input-group">
                                <input type="text" name="search" class="form-control search-input" placeholder="Type something...">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" id="close-search" type="button"><i class="icon-close"></i></button>
                                </span>
                            </div>
                        </form>
                    </div>
                    <nav class="navbar navbar-default">
                        <div class="container-fluid">

                        
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-left">
                                    <li class="dropdown user-dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-language  fa-5x" aria-hidden="true"></i></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="index.php?lang=2">English</a></li>
                                            <li><a href="index.php?lang=1">العربية</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div><!-- /.navbar-collapse -->
                        </div><!-- /.container-fluid -->
                    </nav>
                </div><!-- /Page Header -->
                <!-- Page Inner -->
                <div class="page-inner">
                    <div class="page-title">
                        <h3 class="breadcrumb-header">Dashboard</h3>
                    </div>
                    <div id="main-wrapper">
                        <div class="row">


            <?php
            
            if($action == "slider"){

            ?>
                            <!-- Start Slider Section -->
                            <div class="col-xs-12 col-md-12">
                                <div class="panel panel-white show" id="slider-show">
                                    <div class="panel-heading clearfix">
                                        <h4 class="panel-title">
                                            Edit Slider Section
                                        </h4>
                                    </div>  
                                    <div class="panel-body">
                                        <form method="post" action="">
                                            <div class="form-groupoupWS-76">
                                                <label for="exampleInputEmail1">Enter Title</label>
                                                <input type="text" name="title" class="form-control" id="exampleInputEmail1">
                                            </div>
                                            <input type="submit" name="submit_slider" class="btn btn-primary" value="ADD">
                                        </form>

                                        <div class="row">
                                        <?php

                                            $select_services = $con->prepare("SELECT * FROM slider WHERE lang=?");
                                            $select_services->execute(array($lang));
                                            while( $service = $select_services->fetch()){
                                        ?>
                                            <div class="col-xs-12 col-md-3">
                                                <div class="panel panel-white" style="margin-top: 20px;">
                                                    <div class="panel-body" style="margin-top: 20px;">
                                                        <figure>
                                                            <figcaption><h3> <?php echo $service['title']?> </h3>
                                                            </figcaption>
                                                            <a class="btn btn-danger" href="#">Delete</a>
                                                            <a class="btn btn-primary" href="">Edit</a>
                                                        </figure>
                                                    </div>
                                                </div>
                                            </div>
                                 <?php
                                            }
                                 ?>
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Slider Section -->

                <?php

                if(isset($_POST['submit_slider'])){
                    $title = $_POST['title'];

                    $insert_slider = $con->prepare("INSERT INTO slider(title,lang) VALUES(?,?)");
                    $insert_slider->execute(array($title , $lang));
                    header('Location:index.php?lang=' . $lang . '&action=' . $action);
                }
                
            }elseif($action == "about"){

                ?>

                            <!-- Start About Section -->
                            <div class="col-xs-12 col-md-12">
                                <div class="panel panel-white  " id="about-show">
                                    <div class="panel-heading clearfix">
                                        <h4 class="panel-title">
                                            Edit About Section
                                        </h4>
                                    </div>  
                                    <div class="panel-body">
                                        <form action="" method="post">
                                        <?php
                                        
                                        $select_about = $con->prepare("SELECT * FROM about");
                                        $select_about->execute();
                                        $about = $select_about->fetch();

                                        ?>
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Enter Title</label>
                                                <input type="text" name="title" value="<?php echo $about['title']?>" class="form-control" id="exampleInputEmail1">
                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputPassword1">Enter Brief</label>
                                                <textarea name="body" class="form-control" style="height: 200px;" value="<?php echo $about['des'] ?>"> <?php echo $about['des'] ?> </textarea>
                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputPassword1">Add Link Youtube</label>
                                                <input type="text" name="youtube" value="<?php echo $about['link']?>" class="form-control" style="margin-bottom: 20px; padding: 10px; height: 45px;">
                                            </div>
                                            <input type="submit" name="submit_about" class="btn btn-primary" value="Edit">
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- End About Section -->


                    <?php

                    if(isset($_POST['submit_about'])){

                        $title = $_POST['title'];
                        $body = $_POST['body'];
                        $youtub_link = $_POST['youtube'];

                        $update_about = $con->prepare("UPDATE about SET title=? , des=? , link=? , body=? ");
                        $update_about->execute(array($title , $body , $youtub_link));

                        header('Location:index.php?lang=' . $lang . '&action=' . $action);

                    }
                    
            }elseif($action == "services"){

                    ?>

                            <!-- Start Services Section -->
                            <div class="col-xs-12 col-md-12">
                                <div class="panel panel-white  " id="service-show">
                                    <div class="panel-heading clearfix">
                                        <h4 class="panel-title">
                                            Edit Services Section
                                        </h4>
                                    </div>  
                                    <div class="panel-body">
                                        <form action="" method="post">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Enter Title</label>
                                                <input type="text" name="title" class="form-control" id="exampleInputEmail1">
                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputPassword1">Enter Brief</label>
                                                <textarea name="body" class="form-control" style="height: 200px;"></textarea>
                                            </div>
                                            <input type="submit" name="submit_service" class="btn btn-primary" value="Edit">
                                        </form>

                                        <div class="row">
                                        <?php

                                            $select_services = $con->prepare("SELECT * FROM services WHERE lang=?");
                                            $select_services->execute(array($lang));
                                            while( $service = $select_services->fetch()){
                                        ?>
                                            <div class="col-xs-12 col-md-3">
                                                <div class="panel panel-white" style="margin-top: 20px;">
                                                    <div class="panel-body" style="margin-top: 20px;">
                                                        <figure>
                                                            <figcaption><h3> <?php echo $service['title']?> </h3>
                                                            <p> <?php echo $service['des'] ?> </p>
                                                            </figcaption>
                                                            <a class="btn btn-danger" href="#">Delete</a>
                                                            <a class="btn btn-primary" href="">Edit</a>
                                                        </figure>
                                                    </div>
                                                </div>
                                            </div>
                                 <?php
                                            }
                                 ?>
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Services Section -->

                        <?php

                if(isset($_POST['submit_service'])){

                    $title = $_POST['title'];
                    $body  = $_POST['body'];

                    $insert_service = $con->prepare("INSERT INTO services(title,des,lang) VALUES(?,?,?)");
                    $insert_service->execute(array($title , $body , $lang));
                    header('Location:index.php?lang=' . $lang . '&action=' . $action);
                }



                    }elseif($action == "gallery"){
                        ?>
                            
                            <!-- Start Gallery Section -->
                            <div class="col-xs-12 col-md-12">

                                <div class="panel panel-white  " id="project-show">
                                    <div class="panel panel-white">
                                        <div class="panel-heading clearfix">
                                            <h4 class="panel-title">
                                                Edit Gallery Section
                                            </h4>
                                        </div>  
                                        <div class="panel-body">
                                            <form method="post" action="" enctype= multipart/form-data >
                                                
                                                <div class="form-group">
                                                    <label for="exampleInputPassword1">Uploded Project Image</label>
                                                    <input type="file" class="form-control" style="margin-bottom: 20px; padding: 10px; height: 45px;">
                                                </div>
                                                <input type="submit" name="submit_gallery" class="btn btn-primary" value="Edit">
                                            </form>
                                            <div class="row">

                                               
                                            <?php 
                                            
                                            $select_gallery = $con->prepare("SELECT * FROM gallery");
                                            $select_gallery->execute();
                                            while($gallery = $select_gallery->fetch()){
                                            
                                            ?>
                                                <div class="col-xs-12 col-md-3">
                                                    <div class="client-logo" style="margin-top: 20px;">
                                                        <figure>
                                                            <img class="img-responsive" src="<?php echo $Img_Link . $gallery['img'] ?>" alt="img" style="margin-bottom: 20px;"/>
                                                            <a class="btn btn-danger" href="#">Delete</a>
                                                            <a class="btn btn-primary" href="">Edit</a>
                                                        </figure>
                                                    </div>
                                                </div>

                                                <?php
                                            }
                                                ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Gallery Section -->

                        <?php

                        if(isset($_POST['submit_gallery'])){

                            $avatarName = $_FILES['file']['name'];
                            $avatarSize = $_FILES['file']['size'];
                            $avatarTmp  = $_FILES['file']['tmp_name'];
                            $avatarType = $_FILES['file']['type'];

                            $avatar = time() . '_' . $avatarName;
                            $ImageLink = dirname(__FILE__) . "/../upload//";
                           @move_uploaded_file($avatarTmp, $ImageLink . $avatar);

                           $insert_gallery = $con->prepare("INSERT INTO gallery(img) VALUES(?)");
                           $insert_gallery->execute(array($avatar , $lang));
                           header('Location:index.php?lang=' . $lang . '&action=' . $action);
                        }
                        
                    }elseif($action == "contact"){

                        ?>
                            <!-- Start Contact Section -->
                            <div class="col-xs-12 col-md-12">
                                <div class="panel panel-white  " id="contact-show">
                                    <div class="panel-heading clearfix">
                                        <h4 class="panel-title">
                                            Edit Contact Section 
                                        </h4>
                                    </div>  
                                    <div class="panel-body">
                                        <form action="" method="post">
                                            <?php
                                            
                                            $select_contact = $con->prepare("SELECT * FROM contact");
                                            $select_contact->execute();
                                            $contact = $select_contact->fetch();
                                            ?>
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Edit Address</label>
                                                <input type="text" name="addr" value="<?php echo $contact['address']?>" class="form-control" id="exampleInputEmail1">
                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputPassword1">Edit Email Address</label>
                                                <input type="text" name="email" value="<?php echo $contact['email']?>" class="form-control" id="exampleInputEmail1">
                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputPassword1">Edit Phone Number</label>
                                                <input type="text" name="phone" value="<?php echo $contact['phone']?>" class="form-control" id="exampleInputEmail1">
                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputPassword1">Enter Faceook Profile Link</label>
                                                <input type="text" name="facebook" value="<?php echo $contact['face']?>" class="form-control" id="exampleInputEmail1">
                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputPassword1">Enter Twitter Profile Link</label>
                                                <input type="text" name="twitter" value="<?php echo $contact['twitter']?>" class="form-control" id="exampleInputEmail1">
                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputPassword1">Enter Instagram Profile Link</label>
                                                <input type="text" name="insta" value="<?php echo $contact['insta']?>" class="form-control" id="exampleInputEmail1">
                                            </div>
                                            <input type="submit" name="submit_contact" class="btn btn-primary" value="Edit">
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- End Contact Section -->
                        <?php
                        
                        if(isset($_POST['submit_contact'])){

                            $addr = $_POST['addr'];
                            $email = $_POST['email'];
                            $phone = $_POST['phone'];
                            $facebook = $_POST['facebook'];
                            $twitter = $_POST['twitter'];
                            $insta = $_POST['insta'];

                            $update_contact = $con->prepare("UPDATE contact SET address=? , email=? , phone=? , face=? , twitter=? , insta=?");
                            $update_contact->execute(array($addr , $email , $phone , $facebook , $twitter , $insta));
                           header('Location:index.php?lang=' . $lang . '&action=' . $action);

                        }

                    } // End Action
                        ?>
                        </div>
                    </div><!-- Main Wrapper -->
                    <div class="page-footer">
                        <p>Made with <i class="fa fa-heart"></i> by <a href="https://www.clicktopass.com/" target="_blank">Clicktopass</a></p>
                    </div>
                </div><!-- /Page Inner -->
            </div><!-- /Page Content -->
        </div><!-- /Page Container -->
        
        
        <!-- Javascripts -->
        <script src="assets/js/jquery-3.1.0.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/js/ecaps.min.js"></script>
        <script src="assets/js/js/dashboard.js"></script>
    </body>
</html>
<?php
}else{
    header('Location:login.php');
}
?>