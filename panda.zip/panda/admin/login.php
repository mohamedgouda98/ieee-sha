<!DOCTYPE html>
<html lang="en" dir="rtl">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Responsive Admin Dashboard Template">
        <meta name="keywords" content="admin,dashboard">
        <meta name="author" content="skcats">
        <!-- The above 6 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        
        <!-- Title -->
        <title>Panda Nursery | Admin</title>

        <!-- Styles -->
        <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/css/font-awesome.min.css" rel="stylesheet">
        <!-- <link href="assets/css/icomoon/style.css" rel="stylesheet"> -->
        <link href="assets/css/default.css" rel="stylesheet"/>
        <!-- <link href="assets/css/switchery.min.css" rel="stylesheet"/> -->
        <!-- <link href="assets/css/nv.d3.min.css" rel="stylesheet">   -->
      
        <!-- Theme Styles -->
        <link href="assets/css/ecaps.min.css" rel="stylesheet">
        <link href="assets/css/custom.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        
        <!-- Page Container -->
        <div class="page-container">
                <!-- Page Inner -->
                <div class="page-inner login-page">
                    <div id="main-wrapper" class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6 col-md-3 login-box">
                                <h4 class="login-title">Sign in to your account</h4>
                                <form method="post" action="">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Email address</label>
                                        <input type="email" name="email" class="form-control" id="exampleInputEmail1">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Password</label>
                                        <input type="password" name="password" class="form-control" id="exampleInputPassword1">
                                    </div>
                                    <input type="submit" name="submit" class="btn btn-primary">Login</a>
                                </form>
                            </div>
                        </div>
                    </div>
            </div><!-- /Page Content -->
        </div><!-- /Page Container -->
        
        <?php
        
        include '../back/functions.php';

        if(isset($_POST['submit'])){

            $email = $_POST['email'];
            $password = $_POST['password'];
            
            $user = new login($email , $password);
            $user->login_user();
        }

        
        ?>
        <!-- Javascripts -->
        <script src="assets/js/jquery-3.1.0.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <!-- <script src="assets/js/jquery.slimscroll.min.js"></script> -->
        <!-- <script src="assets/js/jquery.uniform.standalone.js"></script> -->
        <!-- <script src="assets/js/switchery.min.js"></script> -->
        <!-- <script src="assets/js/d3.min.js"></script> -->
        <!-- <script src="assets/js/nv.d3.min.js"></script> -->
        <!-- <script src="assets/js/jquery.flot.min.js"></script> -->
        <!-- <script src="assets/js/jquery.flot.time.min.js"></script> -->
        <!-- <script src="assets/js/jquery.flot.symbol.min.js"></script> -->
        <!-- <script src="assets/js/jquery.flot.resize.min.js"></script> -->
        <!-- <script src="assets/js/jquery.flot.tooltip.min.js"></script> -->
        <!-- <script src="assets/js/jquery.flot.pie.min.js"></script> -->
        <!-- <script src="assets/js/js/chart.min.js"></script> -->
        <script src="assets/js/js/ecaps.min.js"></script>
        <script src="assets/js/js/dashboard.js"></script>
    </body>
</html>