<?php
      session_start();
      ob_start();
  
      if(isset($_SESSION['email'])){
    include '../back/functions.php';

?>

<!DOCTYPE html>
<html lang="en" dir="rtl">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Responsive Admin Dashboard Template">
        <meta name="keywords" content="admin,dashboard">
        <meta name="author" content="skcats">
        <!-- The above 6 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        
        <!-- Title -->
        <title>Panda Nursery | Admin</title>

        <!-- Styles -->
        <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/css/font-awesome.min.css" rel="stylesheet">
        <!-- <link href="assets/css/icomoon/style.css" rel="stylesheet"> -->
        <link href="assets/css/default.css" rel="stylesheet"/>
        <!-- <link href="assets/css/switchery.min.css" rel="stylesheet"/> -->
        <!-- <link href="assets/css/nv.d3.min.css" rel="stylesheet">   -->
      
        <!-- Theme Styles -->
        <link href="assets/css/ecaps.min.css" rel="stylesheet">
        <link href="assets/css/custom.css" rel="stylesheet">

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        
        <!-- Page Container -->
        <div class="page-container">
            <!-- Page Sidebar -->
            <div class="page-sidebar">
                <a class="logo-box" href="index.html">
                    <span>Panda Nursery</span>
                    <i class="icon-radio_button_unchecked" id="fixed-sidebar-toggle-button"></i>
                    <i class="icon-close" id="sidebar-toggle-button-close"></i>
                </a>
                <div class="page-sidebar-inner">
                    <div class="page-sidebar-menu">
                        <ul class="accordion-menu">
                            <li class="active-page">
                                <a href="index.php">
                                    <i class="menu-icon icon-home4"></i><span>Dashboard</span>
                                </a>
                            </li>
                            <li >
                                <a href="profile.php">
                                    <i class="menu-icon icon-inbox"></i><span>Profile</span>
                                </a>
                            </li>
                            <li>
                                <a href="logout.php">
                                    <i class="menu-icon icon-inbox"></i><span>Log Out</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div><!-- /Page Sidebar -->
            
            <!-- Page Content -->
            <div class="page-content">
                <!-- Page Header -->
                <div class="page-header">
                    <div class="search-form">
                        <form action="#" method="GET">
                            <div class="input-group">
                                <input type="text" name="search" class="form-control search-input" placeholder="Type something...">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" id="close-search" type="button"><i class="icon-close"></i></button>
                                </span>
                            </div>
                        </form>
                    </div>
                    <nav class="navbar navbar-default">
                        <div class="container-fluid">
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-left">
                                    <li class="dropdown user-dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-language  fa-5x" aria-hidden="true"></i></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="profile.php?lang=2">English</a></li>
                                            <li><a href="profile.php?lang=2">العربية</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div><!-- /.navbar-collapse -->
                        </div><!-- /.container-fluid -->
                    </nav>
                </div><!-- /Page Header -->
                <!-- Page Inner -->
                <div class="page-inner">
                    <div class="page-title">
                        <h3 class="breadcrumb-header">Dashboard</h3>
                    </div>
                    <div id="main-wrapper">
                        <div class="row">
                            <!-- Start Contact Section -->
                            <div class="col-xs-12 col-md-12">
                                <div class="panel panel-white" id="contact">
                                    <div class="panel-heading clearfix">
                                        <h4 class="panel-title">
                                            Edit Profile Account 
                                        </h4>
                                    </div>  
                                    <div class="panel-body">
                                        
                                    <form action="" method="post">
                                            <?php
                                              
                                            $select_admin_info = $con->prepare("SELECT * FROM user");
                                            $select_admin_info->execute();
                                            $admin_info = $select_admin_info->fetch();

                                            ?>
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Edit Name</label>
                                                <input type="text" name="name" value="<?php echo $admin_info['name']?>" class="form-control" id="exampleInputEmail1">
                                                <input type="hidden" name="confirm_name" value="<?php echo $admin_info['name']?>" class="form-control" id="exampleInputEmail1">                                                    

                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputPassword1">Edit Email Address</label>
                                                <input type="text" name="email" value="<?php echo $admin_info['email']?>" class="form-control" id="exampleInputEmail1">
                                                <input type="hidden" name="confirm_email" value="<?php echo $admin_info['email']?>" class="form-control" id="exampleInputEmail1">                                                                                                
                                            </div>
                                            <div class="row">
                                                <div class="col-xs-12 col-md-6">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">New Password</label>
                                                        <input type="password" name="new_pass" class="form-control" id="exampleInputEmail1">
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-md-6">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Password Confirmation</label>
                                                        <input type="password" name="confirm_pass" class="form-control" id="exampleInputEmail1">
                                                    </div>
                                                </div>

                                                <div class="col-xs-12 col-md-6">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Old Password</label>
                                                        <input type="password" name="old_pass" class="form-control" id="exampleInputEmail1">
                                                        <input type="hidden" name="confirm_old_pass" value="<?php echo $admin_info['password']?>" class="form-control" id="exampleInputEmail1">                                                    
                                                        <input type="hidden" name="user_id" value="<?php echo $admin_info['id']?>" class="form-control" id="exampleInputEmail1">                                                    
                                                    
                                                    </div>
                                                </div>


                                            </div>
                                            <input type="submit" name="submit" class="btn btn-primary" value="Edit">
                                        </form>

                                    <?php
                                    

                                    if(isset($_POST['submit'])){

                                        $newPassword = $_POST['new_pass'];
                                        $confirmNewPassword = $_POST['confirm_pass'];
                                        $oldPassword = $_POST['old_pass'];
                                        $confirmOldPassword = $_POST['confirm_old_pass'];
                                        $userId = $_POST['user_id'];
                                        $useName = $_POST['name'];
                                        $confirmName = $_POST['confirm_name'];
                                        $userEmail = $_POST['email'];
                                        $confirmEmail = $_POST['confirm_email'];

                                        $admin = new changeAdminData($newPassword , $confirmNewPassword , $oldPassword , $confirmOldPassword , $userId , $useName ,$userEmail);
                                        $status_data_admin = $admin->admin_update();

                                        if($status_data_admin == true){
                                            header('Location:profile.php?action=done');
                                         
                                        }else{
                                            header('Location:profile.php?action=yet');
                                           
                                        }


                                        
                                    }
                                    
                                    @$action = $_GET['action'];

                                    if($action== 'done'){
                                        ?>
                                        <div class="alert alert-success" role="alert">
                                             changed successfully .
                                        </div>
                                    <?php
                                    }elseif($action == 'yet'){
                                        ?>
                                        <div class="alert alert-danger" role="alert">
                                            Some Errors .
                                        </div>
                                    <?php
                                    }
                                    
                                    
                                    ?>


                                        
                                    </div>
                                </div>
                            </div>
                            <!-- End Contact Section -->
                        </div>
                    </div><!-- Main Wrapper -->
                    <div class="page-footer">
                        <p>Made with <i class="fa fa-heart"></i> by <a href="https://www.clicktopass.com/" target="_blank">Clicktopass</a></p>
                    </div>
                </div><!-- /Page Inner -->
            </div><!-- /Page Content -->
        </div><!-- /Page Container -->
        
        
        <!-- Javascripts -->
        <script src="assets/js/jquery-3.1.0.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <!-- <script src="assets/js/jquery.slimscroll.min.js"></script> -->
        <!-- <script src="assets/js/jquery.uniform.standalone.js"></script> -->
        <!-- <script src="assets/js/switchery.min.js"></script> -->
        <!-- <script src="assets/js/d3.min.js"></script> -->
        <!-- <script src="assets/js/nv.d3.min.js"></script> -->
        <!-- <script src="assets/js/jquery.flot.min.js"></script> -->
        <!-- <script src="assets/js/jquery.flot.time.min.js"></script> -->
        <!-- <script src="assets/js/jquery.flot.symbol.min.js"></script> -->
        <!-- <script src="assets/js/jquery.flot.resize.min.js"></script> -->
        <!-- <script src="assets/js/jquery.flot.tooltip.min.js"></script> -->
        <!-- <script src="assets/js/jquery.flot.pie.min.js"></script> -->
        <!-- <script src="assets/js/js/chart.min.js"></script> -->
        <script src="assets/js/js/ecaps.min.js"></script>
        <script src="assets/js/js/dashboard.js"></script>
    </body>
</html>
<?php
      }else{
        header('Location:login.php');
      }
?>