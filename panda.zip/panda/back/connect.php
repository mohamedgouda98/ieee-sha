<?php
$host="localhost";
$user="root";
$pass="";
$db="panda";

try{
    $con=new pdo("mysql:host=$host;dbname=$db",$user,$pass , array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'UTF8'"));
    $con->exec("SET CHARACTER SET UTF8");
    
}
catch(PDOException $e){

    echo "not connected" . $e->getMessage();
}

?>
