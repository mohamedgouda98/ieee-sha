<?php

include 'connect.php';


class login{

    private $email;
    private $password;
    public $dbName = 'tstsignal';

     function __construct($email , $password){

        $this->email = $email;
        $this->password = $password;
     }

     // Check if the user found in database or not .

     public function check_user(){
         global $con;
    
         $select_count_user = $con->prepare("SELECT COUNT(email) FROM user WHERE email=? AND password=?");
         $select_count_user->execute(array($this->email , $this->password));
         $count_user = $select_count_user->fetchColumn();

         if($count_user >= 1){
             return true;
         }else{
             return false;
         }
        

     }

     // login user and set sesstion ...

     public function login_user(){

        global $con;

        $user_status = $this->check_user();

        if($user_status == true){
            $select_user_data = $con->prepare("SELECT * FROM user WHERE email=? AND password=?");
            $select_user_data->execute(array($this->email , $this->password));
            $user_data = $select_user_data->fetch();

            session_start();
            $_SESSION['name'] = $user_data['name'];
            $_SESSION['email'] = $this->email;
            header('Location:index.php');

            echo 'Found';
        }else{
            echo 'Not Found';
        }


     }

}
// End Class Login

// Start uodate Data 

class changeAdminData{

    private $newPassword;
    private $confirmNewPassword;
    private $oldPassword;
    private $confirmOldPassword;
    private $userId;
    private $userName;
    private $userEmail;

    // Construcor to get and set vars...

   function __construct($newPass , $confirmNewPass , $oldPass , $confirmOldPass ,  $userId , $userName ,$userEmail){

    $this->newPassword = $newPass;
    $this->confirmNewPassword = $confirmNewPass;
    $this->oldPassword = $oldPass;
    $this->confirmOldPassword = $confirmOldPass;
    $this->userId = $userId;
    $this->userName = $userName;
    $this->userEmail = $userEmail;
   }

   // Start Check data ...

   private function check_data(){

       if($this->newPassword == $this->confirmNewPassword && $this->oldPassword == $this->confirmOldPassword){
           return true;
       }else{
           return false;
       }
   }

   // Start Change Password ...

   private function change_password(){

    $data_status = $this->check_data();

    if($data_status == true){
        
        global $con;
        $update_password = $con->prepare("UPDATE user SET password=? WHERE id=?");
        $update_password ->execute(array($this->newPassword , $this->userId ));
        return true;
    }else{
        return false;
    }

   }

   // Update admin data function ...

   private function update_admin_data(){
        global $con;
        $update_password = $con->prepare("UPDATE user SET name=? , email=? WHERE id=?");
        $update_password ->execute(array($this->userName , $this->userEmail , $this->userId ));
        return true;
   }

   
   public function admin_update(){
       $changePass = $this->change_password();
       $updateInfo = $this->update_admin_data();

       // Print Alert ....

       if($updateInfo == true){
           return true;
       }elseif($changePass == true){
        return true;
        }else{
           return false;
        
       }
   }


}

function selectAll($tableName){

    global $con;

    $select = $con->prepare("SELECT * FROM $tableName");
    $select->execute();
    return $select;
}



// INSERT Functions ---->

// Insert elements Withtout Condition.


function Insertdata($data , $table_name , $data_val){
    global $cont;
    $assign_values = "";
    $data_string = "";
    $status = 0;

    for($i=1 ; $i<= count($data) ; $i++){
        if($assign_values == ""){
        $assign_values = "?";
        $data_string = $data[$i-1];
        }else{
        $assign_values .= ",?";
        $data_string .= ",".$data[$i-1];
        }
    } // End For Loop

    $insert = $cont->prepare("INSERT INTO $table_name($data_string) VALUES($assign_values)");
    if($insert->execute($data_val)){
        $status = 1;
        return $status;
    }else{
        return $status . " " . $data_string;
    }

} // End Insert Function






?>