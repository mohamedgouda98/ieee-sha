<?php


// here 2 function each function for lang , it's easy and all langs in one page.



function title($action , $english , $arabic){
    if($action =="english"){
        return $english;
    }else{
        return $arabic; 
    }
}


function arabic ($word){
   static $words = array(
    "gouda_test" => "arabic",
    
    );
    return $words[$word];
}



function english ($word){
    static  $words = array(
        "gouda_test" => "english",

 
        );

    return $words[$word];
}


/*




*/


?>