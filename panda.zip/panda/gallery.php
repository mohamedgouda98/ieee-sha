<?php 
include 'include/header.php';
include 'back/connect.php';
$image_path = 'upload/'
?>
        <!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area">
            <div class="ht__bradcaump__container">
            	<img src="images/6.png" alt="bradcaump images">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="bradcaump__inner text-center">
                                <h2 class="bradcaump-title">Our Gallery</h2>
                                <nav class="bradcaump-inner">
                                  <a class="breadcrumb-item" href="index.php">Home</a>
                                  <span class="brd-separetor"><img src="images/icons/brad.png" alt="separator images"></span>
                                  <span class="breadcrumb-item active">Gallery</span>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->
		<!-- Start Our Gallery Area -->
		<div class="junior__gallery__area gallery-page-one gallery__masonry__activation gallery--3 bg-image--25 section-padding--lg">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-sm-12 col-md-12">
						<div class="section__title text-center">
							<h2 class="title__line">Our Gallery</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunte magna aliquaet, consectetempora incidunt</p>
						</div>
					</div>
				</div>
				<div class="row galler__wrap masonry__wrap mt--80">
					<!-- Start Single Gallery -->

					<?php 
					 $select_gallery = $con->prepare("SELECT * FROM gallery LIMIT 6");
					 $select_gallery->execute();
					 while($row_gallery = $select_gallery->fetch()){
					
					?>
					<div class="col-lg-3 col-md-4 col-sm-6 col-12 gallery__item cat--2">
						<div class="gallery">
							<div class="gallery__thumb">
								<a href="#">
									<img src="<?php echo $image_path.$row_gallery['img'] ?>" alt="gallery images">
								</a>
							</div>
							<div class="gallery__hover__inner">
								<div class="gallery__hover__action">
									<ul class="gallery__zoom">
										<li><a href="<?php echo $image_path.$row_gallery['img'] ?>" data-lightbox="grportimg" data-title="My caption"><i class="fa fa-search"></i></a></li>
										
									</ul>
								</div>
							</div>
						</div>	
					</div>	

					 <?php }?>
					<!-- End Single Gallery -->

					
				</div>	
			</div>
		</div>
		<!-- End Our Gallery Area -->
<?php include 'include/footer.php'; ?>