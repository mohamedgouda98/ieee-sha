<?php

  include 'back/connect.php';
  $image_path = 'upload/';
  
?>
		<!-- Footer Area -->
		<footer id="footer" class="footer-area footer--2">
			<div class="footer__wrapper bg-image--10 section-padding--lg">
				<div class="container">
					<div class="row">
						<!-- Start Single Widget -->
						<div class="col-lg-4 col-md-6 col-sm-12">
							<div class="footer__widget">
								<div class="ft__logo">
									<a href="index.html">
										<!--	<img src="images/logo/junior.png" alt="logo images">-->
									</a>
								</div>
								
								   <?php 
								   $select_about = $con->prepare("SELECT * FROM about WHERE lang=?");
								   $select_about->execute(array($lang));
								   $row_about = $select_about->fetch();
								
								?>
								 
							

								<div class="ftr__details">
									<p><?php echo $row_about['des']  ?></p>
								</div>
								<div class="ftr__address__inner">

								<?php 
								   $select_contact = $con->prepare("SELECT * FROM contact");
								   $select_contact->execute();
								   $row_contact = $select_contact->fetch();
								
								?>

									<div class="footer__social__icon">
										<ul class="dacre__social__link--2 d-flex justify-content-start">
											<li class="facebook"><a href="<?php echo $row_contact['face'] ?>"><i class="fa fa-facebook"></i></a></li>
											<li class="twitter"><a href="<?php echo $row_contact['twitter'] ?>"><i class="fa fa-twitter"></i></a></li>
											<li class="youtube"><a href="<?php echo $row_contact['insta'] ?>"><i class="fa fa-youtube"></i></a></li>
										</ul>
									</div>
									<div class="ft__btm__title">
										<h4>About Us</h4>
									</div>
								</div>
							</div>
						</div>
						<!-- End Single Widget -->
						<!-- Start Single Wedget -->
						<div class="col-lg-4 col-md-6 col-sm-12 md-mt-40 sm-mt-40">
							<div class="footer__widget">
								<h4>Site links</h4>
								<div class="footer__innner">
									<div class="ftr__latest__post">
										<ul class="ftr__catrgory">
											<li><a href="#">Home</a></li>
											<li><a href="#">About Us</a></li>
											<li><a href="#">Our Services</a></li>
											<li><a href="#">Our Gallery</a></li>
											<li><a href="#">Contact Us</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<!-- End Single Wedget -->
						<!-- Start Single Widget -->
						<div class="col-lg-4 col-md-6 col-sm-12 sm-mt-40">
							<div class="footer__widget">
								<h4>Latest photos</h4>
								<div class="footer__innner">
									<div class="ftr__latest__post">
										<div class="row">

										<?php 
					 $select_gallery = $con->prepare("SELECT * FROM gallery ORDER BY id DESC LIMIT 6");
					 $select_gallery->execute();
					 while($row_gallery = $select_gallery->fetch()){
					
					?>
											<div class="col-4 col-sm-4">
												<!-- Start Single -->
												<div class="ftr__post__thumb">
													<img class="img-fluid" src="<?php echo $image_path. $row_gallery['img'] ?>" alt="post images">
												</div>
												<!-- End Single -->
											</div>
											
					 <?php } ?>
											
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- End Single Widget -->
					</div>
				</div>
				<div class="ft__bottom__images--1 wow flipInX" data-wow-delay="0.6s">
					<img src="images/icons/ft.png" alt="footer images">
				</div>
				<div class="ft__bottom__images--2 wow fadeInRight" data-wow-delay="0.6s">
					<img src="images/icons/ft-2.png" alt="footer images">
				</div>
			</div>
			<!-- .Start Footer Contact Area -->
			<div class="footer__contact__area bg__cat--2">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<div class="footer__contact__wrapper d-flex flex-wrap justify-content-between">
								<div class="single__footer__address">
									<div class="ft__contact__icon">
										<i class="fa fa-home"></i>
									</div>
									<div class="ft__contact__details">
										<p><?php echo $row_contact['address'] ?></p>
										<p>  </p>
									</div>
								</div>
								<div class="single__footer__address">
									<div class="ft__contact__icon">
										<i class="fa fa-phone"></i>
									</div>
									<div class="ft__contact__details">
										<p><a href="#"><?php echo $row_contact['phone'] ?></a></p>
										<p></p>
									</div>
								</div>
								<div class="single__footer__address">
									<div class="ft__contact__icon">
										<i class="fa fa-envelope"></i>
									</div>
									<div class="ft__contact__details">
										<p><a href="#"><?php echo $row_contact['email'] ?></a></p>
										<p></p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- .End Footer Contact Area -->
			<div class="copyright  bg--theme py-3">
				<div class="container">
					<div class="row align-items-center copyright__wrapper justify-content-center">
						<div class="col-lg-12 col-sm-12 col-md-12">
							<div class="coppy__right__inner text-center">
								<p>Copyright <i class="fa fa-copyright"></i> 2019 Panda Nursery. All rights reserved. </p>
								<p>Programming And Designed By <a href="https://clicktopass.com/" target="_blank" >Clicktopass Company</a></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!-- //Footer Area -->

	</div><!-- //Main wrapper -->

	<!-- JS Files -->
	<script src="js/vendor/jquery-3.2.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/plugins.js"></script>
	<script src="js/active.js"></script>
</body>
</html>
