<?php 
include 'include/header.php'; 
include 'back/connect.php';

$image_path = 'upload/';





?>
		<!-- Strat Slider Area -->
		<div class="slide__carosel owl-carousel owl-theme">
		  
		
		<?php 
									
			$select_slider = $con->prepare("SELECT * FROM slider WHERE lang=? ");
				$select_slider->execute(array($lang));
			while($row_slider = $select_slider->fetch()){
									
									
						?>		
	
			<div class="slider__area bg-pngimage--1  d-flex fullscreen justify-content-start align-items-center">
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-lg-12 col-sm-12">
							<div class="slider__activation">
								<!-- Start Single Slide -->
							
								<div class="slide">
							
									<div class="slide__inner">
							
										<div class="slider__text">
											<h2><?php echo $row_slider['title']  ?></h2>
										</div>
									
									</div>
									
								</div>
							
								<!-- End Single Slide -->
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php } ?>
		</div>
		<!-- End Slider Area -->

		<!-- Start Welcame Area -->
		<section class="panda__welcome__area section-padding--md bg-pngimage--2" id="about">
			<div class="container">
				<div class="row">



				<?php 
			    $select_about = $con->prepare("SELECT * FROM about WHERE lang=?");
				$select_about->execute(array($lang));
				$row_about = $select_about->fetch();
			 
			 ?>
					<div class="col-lg-12">
						<div class="section__title text-center">
							<h2 class="title__line"><?php echo $row_about['title'] ?></h2>
						</div>
					</div>
				</div>
			
				<div class="row panda__welcome__wrapper align-items-center">
					<div class="col-md-12 col-lg-6 col-sm-12">
						<div class="welcome__panda__inner">
							
							<p class="wow flipInX"><?php echo $row_about['des'] ?></p>
							<!-- <div class="wel__btn">
								<a class="dcare__btn" href="about-us.html">Read More</a>
							</div> -->
						</div>
					</div>
					<div class="col-md-12 col-lg-6 col-sm-12 md-mt-40 sm-mt-40">
						<div class="panda__Welcome__thumb  wow fadeInUp">
							<img src="images/bg/about.png" alt="images">
							<a class="play__btn" href="<?php echo $row_about['link'] ?>"><i class="fa fa-play"></i></a>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End Welcame Area -->

		<!-- Start Our Service Area -->
		<section class="panda__service bg-image--1 section-padding--bottom section--padding--xlg--top" id="services">
			<div class="container">
				<div class="row">
					<!-- Start Single Service -->
					  
					<?php 
					 
					 $select_service = $con->prepare("SELECT * FROM services WHERE lang=?" );
					 $select_service->execute(array($lang));
					  while($row_service =  $select_service->fetch()){
					
					?>

					<div class="col-lg-3 col-md-6 col-sm-6 col-12" style="margin-bottom:80px;">
						<div class="service bg--white border__color wow fadeInUp">
							<div class="service__icon">
								<img src="images/icons/1.png" alt="icon images">
							</div>
							<div class="service__details">
								<h6><a href="#!"><?php echo $row_service['title']  ?></a></h6>
								<p><?php echo $row_service['des']  ?></p>
								<!-- <div class="service__btn">
									<a class="dcare__btn btn__gray hover--theme min__height-btn" href="#">Read More</a>
								</div> -->
							</div>
						</div>
					</div>
					  <?php } ?>
					<!-- End Single Service -->
					
					
					
				</div>
			</div>
		</section>
		<!-- End Our Service Area -->

		<!-- Start Our Gallery Area -->
		<section class="panda__gallery__area bg--white section-padding--lg" id="gallery">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-sm-12 col-md-12">
						<div class="section__title text-center">
							<h2 class="title__line">Our Gallery</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunte magna aliquaet, consectetempora incidunt</p>
						</div>
					</div>
				</div>
				<div class="row galler__wrap mt--40">
					<!-- Start Single Gallery -->
					<?php 
					 $select_gallery = $con->prepare("SELECT * FROM gallery LIMIT 6");
					 $select_gallery->execute();
					 while($row_gallery = $select_gallery->fetch()){
					
					?>

					<div class="col-lg-4 col-md-6 col-sm-6 col-12">
						<div class="gallery wow fadeInUp">
							<div class="gallery__thumb">
								<a href="#">
									<img src="<?php echo $image_path.$row_gallery['img'] ?>" alt="gallery images">
								</a>
							</div>
							<div class="gallery__hover__inner">
								<div class="gallery__hover__action">
									<ul class="gallery__zoom">
										<li><a href="<?php echo $image_path.$row_gallery['img'] ?>" data-lightbox="grportimg" data-title="My caption"><i class="fa fa-search"></i></a></li>
									</ul>
									<!-- <h4 class="gallery__title"><a href="#">Creating Funny Things</a></h4> -->
								</div>
							</div>
						</div>	
					</div>	
					 <?php } ?>
					<!-- End Single Gallery -->
				
				
					
				
					<div class="gallery__btn">
						<a class="dcare__btn btn__gray hover--theme min__height-btn" href="gallery.php?lang=<?php echo $lang?>&action=<?php echo $action?>">View More</a>
					</div>
				</div>	
			</div>
		</section>
		<!-- End Our Gallery Area -->
		
		<!-- main-contact-section - start -->
		<section id="contact" class="main-contact-section  clearfix">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-sm-12 col-md-12">
						<div class="section__title text-center">
							<h2 class="title__line">Contact Us</h2>
						</div>
					</div>
				</div>
				<div class="row">

					<!-- contact-form - start -->
					<div class="col-lg-6 col-md-12 col-sm-12">
						<form class="contact-form" action="#">

							<div class="row">

								<div class="col-lg-6 col-md-6 col-sm-12">
									<input type="text" placeholder="Name">
								</div>
								<div class="col-lg-6 col-md-6 col-sm-12">
									<input type="email" placeholder="Email">
								</div>

								<div class="col-lg-12 col-md-12 col-sm-12">
									<input type="text" placeholder="Service (optional)">
								</div>

								<div class="col-lg-12 col-md-12 col-sm-12">
									<textarea placeholder="Write your message"></textarea>
								</div>

								<div class="col-lg-12 col-md-12 col-sm-12">
									<a href="#!" class="dcare__btn btn__gray hover--theme min__height-btn" tabindex="0">send message</a>
								</div>

							</div>
						</form>
					</div>
					<!-- contact-form - end -->
					<div class="col-lg-6 col-md-12 col-sm-12 d-none d-md-block">
						<div class="form-img">
							<img class="img-fluid" src="images/4.jpg" alt="">
						</div>
					</div>
				</div>
			</div>

		</section>
		<!-- main-contact-section - end -->

<?php include 'include/footer.php'; ?>