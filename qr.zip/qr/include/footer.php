 
   <!-- Footer -->
   <footer class="sticky-footer bg-white">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright &copy; <a href="#">Mohamed Gouda</a></span>
      </div>
    </div>
  </footer>
  <!-- End of Footer -->
 
 <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>

  <!-- Core plugin JavaScript-->
  <!-- <script src="vendor/jquery-easing/jquery.easing.min.js"></script> -->

  <!-- Custom scripts for all pages-->
   <script src="js/sb-admin-2.min.js"></script>

<script src="js/new.js"></script>

</body>

</html>