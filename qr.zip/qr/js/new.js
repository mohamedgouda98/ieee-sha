document.getElementById("selectCountry").addEventListener("click", function(){
  document.getElementById("tofy").style.display = "block";
});
document.getElementById("tofyR").addEventListener("click", function(){
  document.getElementById("tofy").style.display = "none";
});