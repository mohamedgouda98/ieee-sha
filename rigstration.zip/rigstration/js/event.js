function btnFunction() {
    window.print();
  }



//   document.getElementById("sidebarToggleTop").addEventListener("click",function(){
    
//     document.getElementById("btnPrint").disabled=false;
//   })
  